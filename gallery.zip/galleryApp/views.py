from django.shortcuts import render
from galleryApp.models import *
from django.shortcuts import redirect, render, render_to_response
from django import forms
from django.forms import ModelForm


def index(request):
    pictures = Picture.objects.order_by('-id')[0:8]
    return render(request, 'Index.html', {'pictures': pictures})



class PictureForm(ModelForm):
    title = forms.CharField(required=True)
    desc = forms.CharField(required=True)
    url = forms.CharField(required=True)

    class Meta:
        model = Picture


def register(request):
    print 'post'
    if request.method == 'POST':
        pictureForm = PictureForm(request.POST)
        if pictureForm.is_valid():
            pictureForm.save()

    return render(request, 'Register.html')


