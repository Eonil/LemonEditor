from django.db import models
from django.contrib import admin

# Create your models here.
#    logo = models.ImageField(upload_to='upload_images/company', null=True)
class Portfolio(models.Model):
    url = models.CharField(max_length=300)
    title = models.CharField(max_length=300)
    desc = models.TextField(max_length=2000)

class Contact(models.Model):
    name = models.CharField(max_length=300)
    email = models.CharField(max_length=300)
    subject = models.CharField(max_length=300)
    content = models.TextField(max_length=2000)



