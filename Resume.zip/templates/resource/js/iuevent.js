var skill2=0;
var INIT_IU_skill2=0;
var MAX_IU_skill2=1;
var menu=0;
var INIT_IU_menu=0;
var MAX_IU_menu=1;
var skill3=0;
var INIT_IU_skill3=0;
var MAX_IU_skill3=1;

 /* Decleare Visible Fn */ 
function menuClickVisibleBox19Fn(){
	if( menu==1 ){
		$("#Box19").show("blind", 200);
		$("#Box19").data("runmenuClickVisibleBox19Fn", 1);
		
	}
	else{
		var clicked =$("#Box19").data("runmenuClickVisibleBox19Fn");
		if(clicked == undefined){
			$("#Box19").hide();
		}
		else{
			$("#Box19").hide("blind",200);
		}
	}
	
}
function menuClickVisibleBox19Fn(){
	if( menu==1 ){
		$("#Box19").show("blind", 200);
		$("#Box19").data("runmenuClickVisibleBox19Fn", 1);
		
	}
	else{
		var clicked =$("#Box19").data("runmenuClickVisibleBox19Fn");
		if(clicked == undefined){
			$("#Box19").hide();
		}
		else{
			$("#Box19").hide("blind",200);
		}
	}
	
}

 /* Decleare Frame Fn */ 

$(document).ready(function(){
console.log('ready : iuevent.js');

	skill2 = INIT_IU_skill2;
	menu = INIT_IU_menu;
	skill3 = INIT_IU_skill3;
	

	/* [IU:Boxcopy33] Event Declaration */
	$("#Boxcopy33").click(function(){
		skill2++;
		if( skill2 > MAX_IU_skill2 ){ skill2 = INIT_IU_skill2 }
	
		
	});
	
	/* [IU:Box21] Event Declaration */
	$("#Box21").click(function(){
		menu++;
		if( menu > MAX_IU_menu ){ menu = INIT_IU_menu }
	
		menuClickVisibleBox19Fn();
		menuClickVisibleBox19Fn();
		
	});
	
	/* [IU:Boxcopy34] Event Declaration */
	$("#Boxcopy34").click(function(){
		skill3++;
		if( skill3 > MAX_IU_skill3 ){ skill3 = INIT_IU_skill3 }
	
		
	});
	
	

 /* initialize fn */ 
	menuClickVisibleBox19Fn();
	menuClickVisibleBox19Fn();
	

});