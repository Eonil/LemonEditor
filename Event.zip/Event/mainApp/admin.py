from django.contrib import admin
from mainApp.models import *
# Register your models here.
# admin page
class FaqAdmin(admin.ModelAdmin):
    list_display=('question', 'answer');

class NewsAdmin(admin.ModelAdmin):
    list_display=('title','date' ,'desc');

admin.site.register(Faq, FaqAdmin)
admin.site.register(News, NewsAdmin)
