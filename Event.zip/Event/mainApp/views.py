from django.shortcuts import render
from mainApp.models import *
from django.shortcuts import redirect, render, render_to_response
from django import forms
from django.forms import ModelForm


def index(request):

    newsObject = News.objects.order_by('-id')


    return render(request, 'index.html', {'news':newsObject})


def faq(request):

    faqs = Faq.objects.order_by('-id')

    return render(request, 'faq.html', {
        #faq
        'faq':faqs
    }
    )

def news(request, pageCount = '1'):

    startNewsIndex = (int(pageCount) - 1) * 5
    endNewsIndex = startNewsIndex +5

    countOfNews = News.objects.count();

    if endNewsIndex <=countOfNews:
        endNewsIndex = countOfNews

    news = News.objects.order_by('-id')[startNewsIndex:endNewsIndex]
    pageLinks = range(1, countOfNews/5 +2)
    return render(request, 'news.html', {'pageLinks':pageLinks, 'news':news})

def schedule(request):
    return render(request, 'schedule.html')
    
def about(request):
    return render(request, 'about.html') 