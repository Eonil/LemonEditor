from django.db import models
from django.contrib import admin

# Create your models here.
#    logo = models.ImageField(upload_to='upload_images/company', null=True)
class Faq(models.Model):
    question = models.TextField(max_length=2000)
    answer = models.TextField(max_length=2000)

class News(models.Model):
    title = models.CharField(max_length=200)
    date = models.CharField(max_length=100)
    desc = models.TextField(max_length=1000)
    thumbnail = models.CharField(max_length=200)
    url = models.CharField(max_length=1000)



