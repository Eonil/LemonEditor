<!DOCTYPE html>
<HTML>
    <head>
        <meta charset="utf-8">
        <title>IUTemplate - Blog</title>
        <meta property='og:title' content='IUTemplate - Blog' />
        <meta name='twitter:title' content='IUTemplate - Blog'>
        <meta itemprop='name' content='IUTemplate - Blog'>
        <meta name='keywords' content='IUEditor, Template, Wordpress, Blog'>
        <meta name='author' content='IUEditor'>
        <meta property='og:site_name' content='IUEditor' />
        <meta name='twitter:creator' content='IUEditor'>
        <link rel='icon' type='image/x-icon' href='resource/image/wp_favicon.ico'>

        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href='http://fonts.googleapis.com/css?family=Montserrat' rel='stylesheet' type='text/css'>
        <link href='http://fonts.googleapis.com/css?family=Roboto' rel='stylesheet' type='text/css'>

        <link rel="stylesheet" type="text/css" href="<?php bloginfo('template_url'); ?>/resource/css/reset.css">
        <link rel="stylesheet" type="text/css" href="<?php bloginfo('template_url'); ?>/resource/css/iu.css">
        <link rel="stylesheet" type="text/css" href="<?php bloginfo('template_url'); ?>/resource/css/index.css">

        <script src='http://code.jquery.com/jquery-1.10.2.js'></script>
        <script src='http://code.jquery.com/ui/1.9.2/jquery-ui.js'></script>
        <script type="text/javascript" src="<?php bloginfo('template_url'); ?>/resource/js/jquery.event.swipe.js"></script>
        <script type="text/javascript" src="<?php bloginfo('template_url'); ?>/resource/js/iuframe.js"></script>
        <script type="text/javascript" src="<?php bloginfo('template_url'); ?>/resource/js/iu.js"></script>
        <script type="text/javascript" src="<?php bloginfo('template_url'); ?>/resource/js/iucarousel.js"></script>
        <script type="text/javascript" src="<?php bloginfo('template_url'); ?>/resource/js/iuevent.js"></script>
        <script type="text/javascript" src="<?php bloginfo('template_url'); ?>/resource/js/iuinit.js"></script>
        <script src="http://maps.googleapis.com/maps/api/js?v=3.exp"></script>
        <script src="http://f.vimeocdn.com/js/froogaloop2.min.js"></script>

        <!--[if lt IE 9]>
         <script type="text/javascript" src="<?php bloginfo('template_url'); ?>/resource/js/ie/jquery.backgroundSize.js"></script>
         <script type="text/javascript" src="<?php bloginfo('template_url'); ?>/resource/js/ie/respond.min.js"></script>
         <![endif]-->
        <style id=default>
  .index {background-size:cover; border-left-width:0px; position:relative; display:inherit; border-bottom-color:rgb(0,0,0); border-left-color:rgb(0,0,0); border-bottom-width:0px; background-attachment:fixed; border-top-color:rgb(0,0,0); background-repeat:no-repeat; background-image:url('<?php bloginfo('template_url'); ?>/resource/image/2560x1600.jpg'); background-color:rgb(255,255,255); border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; background-position:center center; }  
  .WPSiteDescription3 {color:rgb(169,169,169); text-align:left; position:relative; line-height:1.50; border-left-color:rgb(0,0,0); background-color:transparent; font-size:11px; border-bottom-color:rgb(0,0,0); margin-top:24px; font-family:'Roboto', sans-serif; background-repeat:no-repeat; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; float:left; border-left-width:0px; display:inherit; letter-spacing:1px; margin-left:14px; border-top-color:rgb(0,0,0); border-bottom-width:0px; }  
  .WPSidebar2 > .WPWidget {border-left-width:0px; position:relative; display:inherit; border-bottom-color:rgb(0,0,0); border-left-color:rgb(0,0,0); border-bottom-width:0px; float:right; border-top-color:rgb(0,0,0); background-repeat:no-repeat; background-color:transparent; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; }  
  .Box5 {border-left-width:0px; position:relative; display:inherit; border-left-color:rgb(0,0,0); width:120px; border-bottom-color:rgb(0,0,0); border-bottom-width:0px; border-top-color:rgb(0,0,0); background-repeat:no-repeat; margin-top:40px; height:1px; background-color:rgb(192,192,192); border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; }  
  .Boxcopy5 {text-align:center; border-left-width:0px; display:inherit; border-left-color:rgb(0,0,0); font-family:Helvetica; border-bottom-width:0px; width:560px; border-top-color:rgb(0,0,0); font-size:12px; background-repeat:no-repeat; opacity:0.50; line-height:2.00; filter:alpha(opacity=50); border-bottom-color:rgb(0,0,0); background-color:transparent; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; top:220px; }  
  .WPSidebar2 > .WPWidget > ul {text-align:right; position:relative; line-height:2.00; filter:alpha(opacity=50); border-left-color:rgb(0,0,0); background-color:transparent; font-size:12px; border-bottom-color:rgb(0,0,0); margin-top:10px; font-family:'Roboto', sans-serif; background-repeat:no-repeat; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; left:0px; opacity:0.50; display:inherit; border-left-width:0px; width:180px; border-top-color:rgb(0,0,0); border-bottom-width:0px; }  
  .Box27 {left:0px; background-position:center center; border-left-width:0px; display:none; border-left-color:rgb(0,0,0); width:50px; border-bottom-color:rgb(0,0,0); border-bottom-width:0px; border-top-color:rgb(0,0,0); background-repeat:no-repeat; background-image:url('<?php bloginfo('template_url'); ?>/resource/image/menu_white.png'); height:60px; background-color:transparent; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; top:0px; }  
  .WPPageLink1 {border-left-width:0px; display:inherit; border-bottom-color:rgb(0,0,0); width:100px; border-left-color:rgb(0,0,0); border-bottom-width:0px; border-top-color:rgb(0,0,0); background-repeat:no-repeat; height:60px; background-color:rgb(148,148,148); border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; }  
  .Section2 {left:0px; border-left-width:0px; position:relative; display:inherit; border-left-color:rgb(213,213,213); width:100.00%; border-bottom-color:rgb(213,213,213); margin-top:0px; border-top-color:rgb(213,213,213); background-repeat:no-repeat; border-bottom-width:1px; background-color:rgb(254,255,255); border-right-width:0px; border-right-color:rgb(213,213,213); border-top-width:1px; border-style:solid; }  
  .WPPageLinks1 {text-align:right; position:relative; display:inherit; margin-top:40px; font-family:'Roboto', sans-serif; width:800px; letter-spacing:1px; font-size:12px; color:rgb(119,121,175); background-repeat:no-repeat; line-height:2.00; border-top-color:rgb(0,0,0); border-left-width:0px; border-left-color:rgb(0,0,0); border-bottom-width:0px; border-bottom-color:rgb(0,0,0); border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; }  
  .WPPageLinks1 > ul > li {float:left; padding:0 0px; display:inline-block; position:relative; }  
  .WPPageLinks1 > ul {text-align:center; }  
  .Boxcopy17 {left:0px; border-left-width:0px; position:relative; display:inherit; border-left-color:rgb(0,0,0); width:100.00%; border-bottom-color:rgb(0,0,0); margin-top:0px; border-top-color:rgb(0,0,0); background-repeat:no-repeat; border-bottom-width:0px; height:80px; background-color:transparent; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; }  
  .Box28 {border-left-width:0px; display:none; border-bottom-color:rgb(0,0,0); width:100.00%; border-left-color:rgb(0,0,0); border-bottom-width:0px; border-top-color:rgb(0,0,0); background-repeat:no-repeat; height:60px; background-color:rgb(245,245,245); border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; top:60px; }  
  .Box6 {left:0px; border-left-width:0px; position:relative; display:inherit; border-left-color:rgb(0,0,0); width:100.00%; border-bottom-color:rgb(0,0,0); margin-top:0px; border-top-color:rgb(0,0,0); background-repeat:no-repeat; border-bottom-width:0px; height:100px; background-color:transparent; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; }  
  .Header {border-left-width:0px; position:relative; display:inherit; border-bottom-color:rgb(0,0,0); border-left-color:rgb(0,0,0); border-bottom-width:0px; border-top-color:rgb(0,0,0); background-repeat:no-repeat; height:60px; overflow:visible; background-color:rgb(254,255,255);background-color:rgba(254,255,255,0.50);filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#7FFEFFFF', endColorstr='#7FFEFFFF'); border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; }  
  .Box3 {border-left-width:0px; position:relative; display:inherit; border-left-color:rgb(0,0,0); width:960px; border-bottom-color:rgb(0,0,0); border-bottom-width:0px; border-top-color:rgb(0,0,0); background-repeat:no-repeat; margin-top:0px; background-color:transparent; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; }  
  .WPMenu1 > div > ul {text-align:right; }  
  .WPMenu1 {color:rgb(254,255,255); text-align:center; position:relative; line-height:1.00; border-left-color:rgb(0,0,0); background-color:transparent; font-size:12px; border-bottom-color:rgb(0,0,0); margin-top:0px; font-family:Arial; background-repeat:no-repeat; border-right-width:0px; border-right-color:rgb(0,0,0); margin-right:-0px; border-top-width:0px; float:right; border-left-width:0px; display:inherit; height:60px; width:240px; border-top-color:rgb(0,0,0); border-bottom-width:0px; }  
  .WPMenu1 > div > ul > li {display:inline-block; padding:0 20px; line-height:60px; position:relative; }  
  .WPArticle1 {border-left-width:0px; position:relative; display:inherit; border-bottom-color:rgb(0,0,0); width:100.00%; border-left-color:rgb(0,0,0); border-bottom-width:0px; border-top-color:rgb(0,0,0); background-repeat:no-repeat; background-color:transparent; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; }  
  .Sectioncopy5 {left:0px; border-left-width:0px; position:relative; display:inherit; border-left-color:rgb(0,0,0); width:100.00%; border-bottom-color:rgb(0,0,0); margin-top:0px; border-top-color:rgb(0,0,0); background-repeat:no-repeat; border-bottom-width:0px; background-color:transparent; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; }  
  .Box12 {left:0px; top:0px; border-left-width:0px; position:fixed; display:inherit; border-left-color:rgb(0,0,0); width:100.00%; border-bottom-color:rgb(0,0,0); border-bottom-width:0px; border-top-color:rgb(0,0,0); background-repeat:no-repeat; height:61px; overflow:visible; z-index:10; background-color:rgb(33,33,33); border-right-color:rgb(0,0,0); border-right-width:0px; border-top-width:0px; }  
  .WPArticleList1 {border-left-width:0px; position:relative; display:inherit; border-left-color:rgb(0,0,0); width:800px; border-bottom-color:rgb(0,0,0); border-bottom-width:0px; border-top-color:rgb(0,0,0); background-repeat:no-repeat; margin-top:0px; background-color:transparent; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; }  
  .pageContent {border-left-width:0px; position:relative; display:inherit; border-bottom-color:rgb(0,0,0); border-left-color:rgb(0,0,0); border-bottom-width:0px; border-top-color:rgb(0,0,0); background-repeat:no-repeat; background-color:rgb(254,255,255);background-color:rgba(254,255,255,0.50);filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#7FFEFFFF', endColorstr='#7FFEFFFF'); border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; }  
  .Boxcopy18 {border-left-width:0px; position:relative; display:inherit; border-bottom-color:rgb(0,0,0); width:960px; border-left-color:rgb(0,0,0); border-bottom-width:0px; border-top-color:rgb(0,0,0); background-repeat:no-repeat; background-color:transparent; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; }  
  .WPSidebar2 {margin-top:50px; position:relative; display:inherit; border-left-color:rgb(0,0,0); width:60.00%; border-bottom-width:0px; border-bottom-color:rgb(0,0,0); border-top-color:rgb(0,0,0); background-repeat:no-repeat; float:right; border-left-width:0px; background-color:transparent; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; margin-right:40px; }  
  .WPMenucopy1 > div > ul {text-align:center; }  
  .WPMenucopy1 {color:rgb(254,255,255); text-align:center; position:relative; line-height:1.00; border-left-color:rgb(0,0,0); background-color:transparent; font-size:14px; border-bottom-color:rgb(0,0,0); background-repeat:no-repeat; font-family:Arial; border-right-width:0px; border-right-color:rgb(0,0,0); margin-right:-0px; border-top-width:0px; float:right; border-left-width:0px; display:inherit; height:60px; width:240px; border-top-color:rgb(0,0,0); border-bottom-width:0px; }  
  .WPMenucopy1 > div > ul > li {display:inline-block; padding:0 10px; line-height:60px; position:relative; }  
  .Box13 {border-left-width:0px; display:inherit; border-bottom-color:rgb(0,0,0); width:960px; border-left-color:rgb(0,0,0); border-bottom-width:0px; border-top-color:rgb(0,0,0); background-repeat:no-repeat; height:100.00%; overflow:visible; background-color:transparent; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; }  
  .WPArticleTitle1 {text-align:center; position:relative; display:inherit; margin-top:100px; font-family:'Roboto', sans-serif; width:100.00%; font-size:21px; border-top-color:rgb(0,0,0); color:rgb(119,121,175); background-repeat:no-repeat; line-height:2.00; border-left-width:0px; border-left-color:rgb(0,0,0); border-bottom-width:0px; border-bottom-color:rgb(0,0,0); border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; }  
  .Section7 {left:0px; border-left-width:0px; position:relative; display:inherit; border-left-color:rgb(0,0,0); width:100.00%; border-bottom-color:rgb(0,0,0); margin-top:0px; border-top-color:rgb(0,0,0); background-repeat:no-repeat; border-bottom-width:0px; height:340px; background-color:transparent; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; }  
  .Boxcopy16 {text-align:left; position:relative; line-height:2.00; filter:alpha(opacity=50); border-left-color:rgb(0,0,0); background-color:transparent; font-size:12px; border-bottom-color:rgb(0,0,0); margin-top:50px; font-family:'Roboto', sans-serif; background-repeat:no-repeat; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; float:left; opacity:0.50; display:inherit; border-left-width:0px; width:30.00%; margin-left:40px; border-top-color:rgb(0,0,0); border-bottom-width:0px; }  
  .Background1 {border-right-color:rgb(0,0,0); display:inherit; border-top-color:rgb(0,0,0); border-top-width:0px; border-bottom-color:rgb(0,0,0); border-left-color:rgb(0,0,0); background-repeat:no-repeat; border-bottom-width:0px; border-right-width:0px; border-left-width:0px; }  
  .WPSiteTitle3 {color:rgb(254,255,255); text-align:left; position:relative; line-height:1.50; border-left-color:rgb(0,0,0); background-color:transparent; font-size:18px; border-bottom-color:rgb(0,0,0); margin-top:17px; font-family:'Roboto', sans-serif; background-repeat:no-repeat; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; float:left; border-left-width:0px; display:inherit; letter-spacing:1px; margin-left:20px; border-top-color:rgb(0,0,0); border-bottom-width:0px; }  
  .WPArticleDate1 {text-align:center; position:relative; display:inherit; margin-top:10px; font-family:'Roboto', sans-serif; width:30.00%; letter-spacing:1px; font-size:12px; color:rgb(154,154,154); background-repeat:no-repeat; line-height:2.00; border-top-color:rgb(0,0,0); border-left-width:0px; border-left-color:rgb(0,0,0); border-bottom-width:0px; border-bottom-color:rgb(0,0,0); border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; }  
  .WPArticleBody1 {left:0px; border-left-width:0px; position:relative; display:inherit; text-align:left; font-family:'Roboto', sans-serif; width:100.00%; font-size:13px; border-top-color:rgb(0,0,0); margin-top:40px; background-repeat:no-repeat; line-height:2.00; border-left-color:rgb(0,0,0); border-bottom-width:0px; border-bottom-color:rgb(0,0,0); border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; }  
  .Boxcopy4 {text-align:center; border-left-width:0px; border-bottom-color:rgb(0,0,0); display:inherit; font-family:'Montserrat', sans-serif; width:700px; border-left-color:rgb(0,0,0); border-top-color:rgb(0,0,0); font-size:30px; background-repeat:no-repeat; line-height:1.30; border-bottom-width:0px; background-color:transparent; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; top:130px; }  
  .WPSidebar2 > .WPWidget > .WPWidgetTitle {text-align:right; position:relative; display:inherit; border-left-color:rgb(0,0,0); font-family:'Roboto', sans-serif; width:180px; font-size:14px; border-top-color:rgb(0,0,0); background-repeat:no-repeat; border-left-width:0px; line-height:1.50; border-bottom-width:0px; border-bottom-color:rgb(0,0,0); background-color:transparent; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; }  
</style>
<style type="text/css" media ='screen and (min-width:768px) and (max-width:959px)' id='style768'>  .WPSidebar2 > .WPWidget > ul {width:228px; text-align:center; }  
  .Box3 {width:768px; }  
  .WPArticleList1 {width:720px; }  
  .Boxcopy18 {width:768px; }  
  .WPSidebar2 {width:684px; margin-right:42px; }  
  .WPMenucopy1 {font-size:12px; }  
  .Box13 {width:768px; }  
  .Boxcopy16 {margin-left:0px; width:100.00%; text-align:center; }  
  .WPSidebar2 > .WPWidget > .WPWidgetTitle {width:228px; text-align:center; }  
</style>
<style type="text/css" media ='screen and (max-width:767px)' id='style320'>  .WPSiteDescription3 {display:none; }  
  .Boxcopy5 {top:140px; width:260px; font-size:11px; }  
  .Box27 {display:inherit; }  
  .Box28 {display:inherit; }  
  .Box6 {height:50px; }  
  .Box3 {width:100.00%; }  
  .WPMenu1 {display:none; }  
  .Sectioncopy5 {height:180px; }  
  .WPArticleList1 {margin-top:50px; width:86.00%; }  
  .Boxcopy18 {width:320px; }  
  .WPSidebar2 {display:none; margin-right:-0px; }  
  .WPMenucopy1 {font-family:'Roboto', sans-serif; color:rgb(0,0,0); width:100.00%; }  
  .Box13 {width:100.00%; }  
  .WPArticleTitle1 {line-height:1.50; }  
  .Section7 {height:280px; }  
  .Boxcopy16 {margin-left:0px; width:100.00%; text-align:center; }  
  .WPSiteTitle3 {margin-left:54px; }  
  .Boxcopy4 {top:80px; width:300px; font-size:18px; }  
</style>

    </head>
    <body>
<div id="index" class='IUPage IUSheet IUBox  index' >
  <div id="Header" class='IUHeader IUBox  Header'>
    <div id="Box12" class='IUBox  Box12' horizontalCenter='1'>
      <div id="Box13" class='IUBox  Box13' horizontalCenter='1'>
       <div id="WPSiteTitle3" class='WPSiteTitle IUBox  WPSiteTitle3' ><h1><a href="<?php echo home_url(); ?>"><?bloginfo()?></a></h1></div>
       <div id="WPSiteDescription3" class='WPSiteDescription IUBox  WPSiteDescription3' ><?bloginfo('description')?></div>
       <div id="WPMenu1" class='WPMenu IUBox  WPMenu1' ><? wp_nav_menu() ?></div>
        <div id="Box27" class='IUBox  Box27'></div>
        <div id="Box28" class='IUBox  Box28'>
         <div id="WPMenucopy1" class='WPMenu IUBox  WPMenucopy1' ><? wp_nav_menu() ?></div>
        </div>
      </div>
    </div>
  </div>
  <div id="pageContent" class='IUPageContent IUBox  pageContent'>
    <div id="Section7" class='IUSection IUBox  Section7'>
      <div id="Boxcopy4" class='IUBox  Boxcopy4' horizontalCenter='1'>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>  
      </div>
      <div id="Boxcopy5" class='IUBox  Boxcopy5' horizontalCenter='1'>
        <p>Curabitur varius, justo vel lobortis porta, purus nibh tincidunt dui, nec egestas nisl felis ut ex.<br>Donec ut feugiat felis. Donec aliquet vulputate rutrum.</p>  
      </div>
    </div>
    <div id="Section2" class='IUSection IUBox  Section2'>
      <div id="Box3" class='IUBox  Box3' horizontalCenter='1'>
       <div id="WPArticleList1" class='WPArticleList IUBox  WPArticleList1' horizontalCenter='1' ><? while ( have_posts() ) : the_post(); ?>  <div id="WPArticle1" class='WPArticle IUBox  WPArticle1'>
          <div id="WPArticleTitle1" class='WPArticleTitle IUBox  WPArticleTitle1' horizontalCenter='1' ><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></div>
          <div id="WPArticleDate1" class='WPArticleDate IUBox  WPArticleDate1' horizontalCenter='1' ><?php echo get_the_date(); ?></div>
           <div id="Box5" class='IUBox  Box5' horizontalCenter='1'></div>
          <div id="WPArticleBody1" class='WPArticleBody IUBox  WPArticleBody1' ><?php the_content(); ?></div>
         </div>
       <? endwhile ?></div>
       <div id="WPPageLinks1" class='WPPageLinks IUBox  WPPageLinks1' horizontalCenter='1' ><?php
           global $wp_query;
           $big = 999999999;
           echo paginate_links( array(
               'base' => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
               'format' => '?paged=%#%',
               'current' => max( 1, get_query_var('paged') ),
               'total' => $wp_query->max_num_pages,
               'type' => 'list',
           ) );
           ?></div>
        <div id="Box6" class='IUBox  Box6'></div>
      </div>
    </div>
    <div id="Sectioncopy5" class='IUSection IUBox  Sectioncopy5'>
      <div id="Boxcopy18" class='IUBox  Boxcopy18' horizontalCenter='1'>
        <div id="Boxcopy16" class='IUBox  Boxcopy16'>
          <p>Copyright (C) Blog Owner all rights reserved<br>Wordpress Theme powered by IUEditor</p>  
        </div>
       <div id="WPSidebar2" class='WPSidebar IUBox  WPSidebar2' ><?php dynamic_sidebar( 'IUWidgets' ); ?>  <div id="WPWidget2" class='WPWidget IUBox  WPWidget2'>
           <div id="WPWidgetTitle2" class='WPWidgetTitle IUBox  WPWidgetTitle2'></div>
           <div id="WPWidgetBody2" class='WPWidgetBody IUBox  WPWidgetBody2'></div>
         </div>
       </div>
        <div id="Boxcopy17" class='IUBox  Boxcopy17'></div>
      </div>
    </div>
  </div>
</div>

    </body>
</HTML>


