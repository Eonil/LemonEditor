 var menu=0;
 var INIT_IU_menu=0;
 var MAX_IU_menu=1;
 /* Decleare Visible Fn */ 
 function menuClickVisibleBox28Fn(){
  if( menu==1 ){
   $("#Box28").show("blind", 1, function(){reframeCenterIU('#Box28' ,false)});
   $("#Box28").data("runmenuClickVisibleBox28Fn", 1);
  }
  else{
   var clicked =$("#Box28").data("runmenuClickVisibleBox28Fn");
   if(clicked == undefined){
   	$("#Box28").hide();
   }
   else{
   	$("#Box28").hide("blind", 1);
   }}
 }function menuClickVisibleBox28Fn(){
  if( menu==1 ){
   $("#Box28").show("blind", 1, function(){reframeCenterIU('#Box28' ,false)});
   $("#Box28").data("runmenuClickVisibleBox28Fn", 1);
  }
  else{
   var clicked =$("#Box28").data("runmenuClickVisibleBox28Fn");
   if(clicked == undefined){
   	$("#Box28").hide();
   }
   else{
   	$("#Box28").hide("blind", 1);
   }}
 }function menuClickVisibleBox28Fn(){
  if( menu==1 ){
   $("#Box28").show("blind", 1, function(){reframeCenterIU('#Box28' ,false)});
   $("#Box28").data("runmenuClickVisibleBox28Fn", 1);
  }
  else{
   var clicked =$("#Box28").data("runmenuClickVisibleBox28Fn");
   if(clicked == undefined){
   	$("#Box28").hide();
   }
   else{
   	$("#Box28").hide("blind", 1);
   }}
 }function menuClickVisibleBox28Fn(){
  if( menu==1 ){
   $("#Box28").show("blind", 1, function(){reframeCenterIU('#Box28' ,false)});
   $("#Box28").data("runmenuClickVisibleBox28Fn", 1);
  }
  else{
   var clicked =$("#Box28").data("runmenuClickVisibleBox28Fn");
   if(clicked == undefined){
   	$("#Box28").hide();
   }
   else{
   	$("#Box28").hide("blind", 1);
   }}
 }function menuClickVisibleBox28Fn(){
  if( menu==1 ){
   $("#Box28").show("blind", 1, function(){reframeCenterIU('#Box28' ,false)});
   $("#Box28").data("runmenuClickVisibleBox28Fn", 1);
  }
  else{
   var clicked =$("#Box28").data("runmenuClickVisibleBox28Fn");
   if(clicked == undefined){
   	$("#Box28").hide();
   }
   else{
   	$("#Box28").hide("blind", 1);
   }}
 } /* Decleare Frame Fn */ 
$(document).ready(function(){
console.log('ready : iuevent.js');
  menu = INIT_IU_menu;
   /* [IU:Box27] Event Declaration */
   $("#Box27").css('cursor', 'pointer');
   $("#Box27").click(function(){  menu++;  
     if( menu > MAX_IU_menu ){ menu = INIT_IU_menu }  
      menuClickVisibleBox28Fn();
      menuClickVisibleBox28Fn();
      menuClickVisibleBox28Fn();
      menuClickVisibleBox28Fn();
      menuClickVisibleBox28Fn();
   });
   /* initialize fn */   
   menuClickVisibleBox28Fn();
   menuClickVisibleBox28Fn();
   menuClickVisibleBox28Fn();
   menuClickVisibleBox28Fn();
   menuClickVisibleBox28Fn();
});
