<!DOCTYPE html>
<HTML>
    <head>
        <meta charset="utf-8">
        <title>IUTemplate - Blog</title>
        <meta property='og:title' content='IUTemplate - Blog' />
        <meta name='twitter:title' content='IUTemplate - Blog'>
        <meta itemprop='name' content='IUTemplate - Blog'>
        <meta name='keywords' content='IUEditor, Template, Wordpress, Blog'>
        <meta name='author' content='IUEditor'>
        <meta property='og:site_name' content='IUEditor' />
        <meta name='twitter:creator' content='IUEditor'>
        <link rel='icon' type='image/x-icon' href='resource/image/wp_favicon.ico'>

        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href='http://fonts.googleapis.com/css?family=Montserrat' rel='stylesheet' type='text/css'>
        <link href='http://fonts.googleapis.com/css?family=Roboto' rel='stylesheet' type='text/css'>

        <link rel="stylesheet" type="text/css" href="<?php bloginfo('template_url'); ?>/resource/css/reset.css">
        <link rel="stylesheet" type="text/css" href="<?php bloginfo('template_url'); ?>/resource/css/iu.css">
        <link rel="stylesheet" type="text/css" href="<?php bloginfo('template_url'); ?>/resource/css/home.css">

        <script src='http://code.jquery.com/jquery-1.10.2.js'></script>
        <script src='http://code.jquery.com/ui/1.9.2/jquery-ui.js'></script>
        <script type="text/javascript" src="<?php bloginfo('template_url'); ?>/resource/js/jquery.event.swipe.js"></script>
        <script type="text/javascript" src="<?php bloginfo('template_url'); ?>/resource/js/iuframe.js"></script>
        <script type="text/javascript" src="<?php bloginfo('template_url'); ?>/resource/js/iu.js"></script>
        <script type="text/javascript" src="<?php bloginfo('template_url'); ?>/resource/js/iucarousel.js"></script>
        <script type="text/javascript" src="<?php bloginfo('template_url'); ?>/resource/js/iuevent.js"></script>
        <script type="text/javascript" src="<?php bloginfo('template_url'); ?>/resource/js/iuinit.js"></script>
        <script src="http://maps.googleapis.com/maps/api/js?v=3.exp"></script>
        <script src="http://f.vimeocdn.com/js/froogaloop2.min.js"></script>

        <!--[if lt IE 9]>
         <script type="text/javascript" src="<?php bloginfo('template_url'); ?>/resource/js/ie/jquery.backgroundSize.js"></script>
         <script type="text/javascript" src="<?php bloginfo('template_url'); ?>/resource/js/ie/respond.min.js"></script>
         <![endif]-->
        <style id=default>
  .home {background-size:cover; border-left-width:0px; position:relative; display:inherit; border-bottom-color:rgb(0,0,0); border-left-color:rgb(0,0,0); border-bottom-width:0px; background-attachment:fixed; border-top-color:rgb(0,0,0); background-repeat:no-repeat; background-image:url('<?php bloginfo('template_url'); ?>/resource/image/2560x1600.jpg'); background-color:rgb(255,255,255); border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; background-position:center center; }  
  .Section8 {left:0px; border-left-width:0px; position:relative; display:inherit; border-left-color:rgb(0,0,0); width:100.00%; border-bottom-color:rgb(0,0,0); margin-top:0px; border-top-color:rgb(0,0,0); background-repeat:no-repeat; border-bottom-width:0px; height:340px; background-color:transparent; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; }  
  .WPArticleList2 {border-left-width:0px; position:relative; display:inherit; border-bottom-color:rgb(0,0,0); width:500px; border-left-color:rgb(0,0,0); border-bottom-width:0px; border-top-color:rgb(0,0,0); background-repeat:no-repeat; background-color:transparent; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; }  
  .WPSiteDescription3 {color:rgb(169,169,169); text-align:left; position:relative; line-height:1.50; border-left-color:rgb(0,0,0); background-color:transparent; font-size:11px; border-bottom-color:rgb(0,0,0); margin-top:24px; font-family:'Roboto', sans-serif; background-repeat:no-repeat; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; float:left; border-left-width:0px; display:inherit; letter-spacing:1px; margin-left:14px; border-top-color:rgb(0,0,0); border-bottom-width:0px; }  
  .WPSidebar1 > .WPWidget > ul {text-align:right; position:relative; line-height:2.00; filter:alpha(opacity=50); border-left-color:rgb(0,0,0); background-color:transparent; font-size:12px; border-bottom-color:rgb(0,0,0); margin-top:10px; font-family:'Roboto', sans-serif; background-repeat:no-repeat; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; left:0px; opacity:0.50; display:inherit; border-left-width:0px; width:180px; border-top-color:rgb(0,0,0); border-bottom-width:0px; }  
  .Box21 {border-bottom-left-radius:64px; position:relative; border-bottom-right-radius:64px; border-left-color:rgb(0,0,0); background-color:transparent; background-image:url('https://s3.amazonaws.com/uifaces/faces/twitter/celikovic/128.jpg'); border-bottom-color:rgb(0,0,0); margin-top:20px; background-repeat:no-repeat; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-left-radius:64px; border-top-width:0px; border-top-right-radius:64px; float:left; border-left-width:0px; display:inherit; height:128px; width:128px; margin-left:0px; border-top-color:rgb(0,0,0); border-bottom-width:0px; }  
  .WPArticle2 {border-left-width:0px; position:relative; display:inherit; border-left-color:rgb(0,0,0); width:100.00%; border-bottom-color:rgb(0,0,0); border-bottom-width:0px; border-top-color:rgb(0,0,0); background-repeat:no-repeat; margin-top:-1px; background-color:transparent; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; }  
  .Boxcopy1 {left:0px; border-left-width:0px; position:relative; display:inherit; border-left-color:rgb(0,0,0); width:100.00%; border-bottom-color:rgb(234,234,234); margin-top:0px; border-top-color:rgb(0,0,0); background-repeat:no-repeat; border-bottom-width:0px; height:20px; background-color:transparent; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; }  
  .Box7 {border-left-width:0px; display:inherit; border-bottom-color:rgb(0,0,0); width:960px; border-left-color:rgb(0,0,0); border-bottom-width:0px; border-top-color:rgb(0,0,0); background-repeat:no-repeat; height:100.00%; background-color:transparent; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; top:0px; }  
  .Box16 {left:0px; border-left-width:0px; position:relative; display:inherit; border-left-color:rgb(0,0,0); width:100.00%; border-bottom-color:rgb(0,0,0); margin-top:0px; border-top-color:rgb(213,213,213); background-repeat:no-repeat; border-bottom-width:0px; height:20px; background-color:transparent; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:1px; border-style:solid; }  
  .Box27 {left:0px; background-position:center center; border-left-width:0px; display:none; border-left-color:rgb(0,0,0); width:50px; border-bottom-color:rgb(0,0,0); border-bottom-width:0px; border-top-color:rgb(0,0,0); background-repeat:no-repeat; background-image:url('<?php bloginfo('template_url'); ?>/resource/image/menu_white.png'); height:60px; background-color:transparent; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; top:0px; }  
  .Box11 {left:0px; border-left-width:0px; position:relative; display:inherit; border-left-color:rgb(0,0,0); width:100.00%; border-bottom-color:rgb(0,0,0); margin-top:0px; border-top-color:rgb(0,0,0); background-repeat:no-repeat; border-bottom-width:0px; height:80px; background-color:transparent; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; }  
  .Boxcopy3 {color:rgb(119,121,175); text-align:left; position:relative; line-height:1.50; border-left-color:rgb(0,0,0); background-color:transparent; font-size:24px; border-bottom-color:rgb(94,94,94); margin-top:25px; font-family:'Roboto', sans-serif; background-repeat:no-repeat; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; left:22px; border-left-width:0px; display:inherit; width:210px; border-top-color:rgb(0,0,0); border-bottom-width:0px; }  
  .Box17 {border-left-width:0px; position:relative; display:inherit; border-left-color:rgb(0,0,0); width:100.00%; border-bottom-color:rgb(0,0,0); border-bottom-width:0px; border-top-color:rgb(0,0,0); background-repeat:no-repeat; margin-top:0px; height:100px; background-color:transparent; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; }  
  .Box8 {text-align:center; border-left-width:0px; border-bottom-color:rgb(0,0,0); display:inherit; font-family:'Montserrat', sans-serif; width:700px; border-left-color:rgb(0,0,0); border-top-color:rgb(0,0,0); font-size:30px; background-repeat:no-repeat; line-height:1.30; border-bottom-width:0px; background-color:transparent; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; top:130px; }  
  .WPArticleTitle2 {left:0px; text-align:left; position:relative; display:inherit; border-left-color:rgb(0,0,0); font-family:'Roboto', sans-serif; font-size:16px; border-left-width:0px; border-top-color:rgb(0,0,0); margin-top:0px; line-height:2.00; background-repeat:no-repeat; border-bottom-width:0px; border-bottom-color:rgb(0,0,0); border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; }  
  .Box28 {border-left-width:0px; display:none; border-bottom-color:rgb(0,0,0); width:100.00%; border-left-color:rgb(0,0,0); border-bottom-width:0px; border-top-color:rgb(0,0,0); background-repeat:no-repeat; height:60px; background-color:rgb(245,245,245); border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; top:60px; }  
  .Header {border-left-width:0px; position:relative; display:inherit; border-bottom-color:rgb(0,0,0); border-left-color:rgb(0,0,0); border-bottom-width:0px; border-top-color:rgb(0,0,0); background-repeat:no-repeat; height:60px; overflow:visible; background-color:rgb(254,255,255);background-color:rgba(254,255,255,0.50);filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#7FFEFFFF', endColorstr='#7FFEFFFF'); border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; }  
  .Box22 {color:rgb(94,94,94); text-align:left; position:relative; line-height:2.00; border-left-color:rgb(0,0,0); background-color:transparent; font-size:12px; border-bottom-color:rgb(0,0,0); margin-top:10px; font-family:'Roboto', sans-serif; background-repeat:no-repeat; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; left:21px; border-left-width:0px; display:inherit; width:210px; border-top-color:rgb(0,0,0); border-bottom-width:0px; }  
  .WPSidebar1 {margin-top:50px; position:relative; display:inherit; border-left-color:rgb(0,0,0); width:60.00%; border-bottom-width:0px; border-bottom-color:rgb(0,0,0); border-top-color:rgb(0,0,0); background-repeat:no-repeat; float:right; border-left-width:0px; background-color:transparent; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; margin-right:40px; }  
  .WPMenu1 > div > ul {text-align:right; }  
  .WPMenu1 {color:rgb(254,255,255); text-align:center; position:relative; line-height:1.00; border-left-color:rgb(0,0,0); background-color:transparent; font-size:12px; border-bottom-color:rgb(0,0,0); margin-top:0px; font-family:Arial; background-repeat:no-repeat; border-right-width:0px; border-right-color:rgb(0,0,0); margin-right:-0px; border-top-width:0px; float:right; border-left-width:0px; display:inherit; height:60px; width:240px; border-top-color:rgb(0,0,0); border-bottom-width:0px; }  
  .WPMenu1 > div > ul > li {display:inline-block; padding:0 20px; line-height:60px; position:relative; }  
  .Section4 {left:0px; border-left-width:0px; position:relative; display:inherit; border-left-color:rgb(0,0,0); width:100.00%; border-bottom-color:rgb(0,0,0); margin-top:0px; border-top-color:rgb(0,0,0); background-repeat:no-repeat; border-bottom-width:0px; background-color:transparent; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; }  
  .Box9 {text-align:center; border-left-width:0px; display:inherit; border-left-color:rgb(0,0,0); font-family:Helvetica; border-bottom-width:0px; width:560px; border-top-color:rgb(0,0,0); font-size:12px; background-repeat:no-repeat; opacity:0.50; line-height:2.00; filter:alpha(opacity=50); border-bottom-color:rgb(0,0,0); background-color:transparent; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; top:220px; }  
  .WPArticleDate2 {left:0px; text-align:left; position:relative; display:inherit; margin-top:5px; font-family:'Roboto', sans-serif; font-size:12px; border-left-width:0px; border-top-color:rgb(0,0,0); color:rgb(154,154,154); line-height:2.00; background-repeat:no-repeat; border-left-color:rgb(0,0,0); border-bottom-width:0px; border-bottom-color:rgb(0,0,0); border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; }  
  .Box12 {left:0px; top:0px; border-left-width:0px; position:fixed; display:inherit; border-left-color:rgb(0,0,0); width:100.00%; border-bottom-color:rgb(0,0,0); border-bottom-width:0px; border-top-color:rgb(0,0,0); background-repeat:no-repeat; height:61px; overflow:visible; z-index:10; background-color:rgb(33,33,33); border-right-color:rgb(0,0,0); border-right-width:0px; border-top-width:0px; }  
  .Box23 {color:rgb(66,66,66); text-align:left; position:relative; line-height:2.00; border-left-color:rgb(0,0,0); background-color:transparent; font-size:12px; border-bottom-color:rgb(0,0,0); margin-top:20px; font-family:'Roboto', sans-serif; background-repeat:no-repeat; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; left:0px; border-left-width:0px; display:inherit; width:100.00%; border-top-color:rgb(0,0,0); border-bottom-width:0px; }  
  .Box10 {border-left-width:0px; position:relative; display:inherit; border-bottom-color:rgb(0,0,0); width:960px; border-left-color:rgb(0,0,0); border-bottom-width:0px; border-top-color:rgb(0,0,0); background-repeat:no-repeat; background-color:transparent; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; }  
  .Section3 {left:0px; border-left-width:0px; position:relative; display:inherit; border-left-color:rgb(213,213,213); width:100.00%; border-bottom-color:rgb(213,213,213); margin-top:0px; border-top-color:rgb(213,213,213); background-repeat:no-repeat; border-bottom-width:1px; background-color:rgb(249,249,249); border-right-width:0px; border-right-color:rgb(213,213,213); border-top-width:1px; border-style:solid; }  
  .WPMenucopy1 > div > ul {text-align:center; }  
  .WPMenucopy1 {color:rgb(254,255,255); text-align:center; position:relative; line-height:1.00; border-left-color:rgb(0,0,0); background-color:transparent; font-size:14px; border-bottom-color:rgb(0,0,0); background-repeat:no-repeat; font-family:Arial; border-right-width:0px; border-right-color:rgb(0,0,0); margin-right:-0px; border-top-width:0px; float:right; border-left-width:0px; display:inherit; height:60px; width:240px; border-top-color:rgb(0,0,0); border-bottom-width:0px; }  
  .WPMenucopy1 > div > ul > li {display:inline-block; padding:0 10px; line-height:60px; position:relative; }  
  .Box13 {border-left-width:0px; display:inherit; border-bottom-color:rgb(0,0,0); width:960px; border-left-color:rgb(0,0,0); border-bottom-width:0px; border-top-color:rgb(0,0,0); background-repeat:no-repeat; height:100.00%; overflow:visible; background-color:transparent; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; }  
  .Box19 {margin-top:0px; position:relative; display:inherit; border-left-color:rgb(0,0,0); width:500px; border-bottom-width:0px; border-bottom-color:rgb(0,0,0); border-top-color:rgb(0,0,0); background-repeat:no-repeat; float:right; border-left-width:0px; background-color:transparent; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; margin-right:20px; }  
  .Box1 {text-align:left; position:relative; line-height:2.00; filter:alpha(opacity=50); border-left-color:rgb(0,0,0); background-color:transparent; font-size:12px; border-bottom-color:rgb(0,0,0); margin-top:50px; font-family:'Roboto', sans-serif; background-repeat:no-repeat; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; float:left; opacity:0.50; display:inherit; border-left-width:0px; width:30.00%; margin-left:40px; border-top-color:rgb(0,0,0); border-bottom-width:0px; }  
  .Box15 {border-left-width:0px; position:relative; display:inherit; border-left-color:rgb(0,0,0); width:960px; border-bottom-color:rgb(0,0,0); border-bottom-width:0px; border-top-color:rgb(0,0,0); background-repeat:no-repeat; margin-top:100px; background-color:transparent; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; }  
  .WPSidebar1 > .WPWidget {border-left-width:0px; position:relative; display:inherit; border-bottom-color:rgb(0,0,0); border-left-color:rgb(0,0,0); border-bottom-width:0px; float:right; border-top-color:rgb(0,0,0); background-repeat:no-repeat; background-color:transparent; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; }  
  .Background1 {border-right-color:rgb(0,0,0); display:inherit; border-top-color:rgb(0,0,0); border-top-width:0px; border-bottom-color:rgb(0,0,0); border-left-color:rgb(0,0,0); background-repeat:no-repeat; border-bottom-width:0px; border-right-width:0px; border-left-width:0px; }  
  .WPSiteTitle3 {color:rgb(254,255,255); text-align:left; position:relative; line-height:1.50; border-left-color:rgb(0,0,0); background-color:transparent; font-size:18px; border-bottom-color:rgb(0,0,0); margin-top:17px; font-family:'Roboto', sans-serif; background-repeat:no-repeat; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; float:left; border-left-width:0px; display:inherit; letter-spacing:1px; margin-left:20px; border-top-color:rgb(0,0,0); border-bottom-width:0px; }  
  .Box18 {color:rgb(119,121,175); text-align:left; position:relative; line-height:2.50; border-left-color:rgb(0,0,0); background-color:transparent; font-size:24px; border-bottom-color:rgb(94,94,94); margin-top:12px; font-family:'Roboto', sans-serif; background-repeat:no-repeat; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; left:0px; border-left-width:0px; display:inherit; height:60px; width:100.00%; border-top-color:rgb(0,0,0); border-style:solid; border-bottom-width:2px; }  
  .pageContent {border-left-width:0px; position:relative; display:inherit; border-bottom-color:rgb(0,0,0); border-left-color:rgb(0,0,0); border-bottom-width:0px; border-top-color:rgb(0,0,0); background-repeat:no-repeat; background-color:rgb(254,255,255);background-color:rgba(254,255,255,0.50);filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#7FFEFFFF', endColorstr='#7FFEFFFF'); border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; }  
  .Box20 {border-left-width:0px; position:relative; display:inherit; border-left-color:rgb(0,0,0); width:360px; border-bottom-width:0px; border-bottom-color:rgb(0,0,0); border-top-color:rgb(0,0,0); background-repeat:no-repeat; float:left; margin-top:0px; margin-left:20px; background-color:transparent; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; }  
  .WPSidebar1 > .WPWidget > .WPWidgetTitle {text-align:right; position:relative; display:inherit; border-left-color:rgb(0,0,0); font-family:'Roboto', sans-serif; width:180px; font-size:14px; border-top-color:rgb(0,0,0); background-repeat:no-repeat; border-left-width:0px; line-height:1.50; border-bottom-width:0px; border-bottom-color:rgb(0,0,0); background-color:transparent; border-right-width:0px; border-right-color:rgb(0,0,0); border-top-width:0px; }  
</style>
<style type="text/css" media ='screen and (min-width:768px) and (max-width:959px)' id='style768'>  .WPArticleList2 {width:720px; }  
  .WPSidebar1 > .WPWidget > ul {width:228px; text-align:center; }  
  .Box7 {width:768px; }  
  .WPSidebar1 {width:684px; margin-right:42px; }  
  .Box23 {width:50.00%; margin-top:-118px; left:230px; }  
  .Box10 {width:768px; }  
  .WPMenucopy1 {font-size:12px; }  
  .Box13 {width:768px; }  
  .Box19 {width:720px; margin-top:30px; margin-right:24px; }  
  .Box1 {margin-left:0px; width:100.00%; text-align:center; }  
  .Box15 {width:768px; }  
  .Box20 {width:720px; margin-left:24px; }  
  .WPSidebar1 > .WPWidget > .WPWidgetTitle {width:228px; text-align:center; }  
</style>
<style type="text/css" media ='screen and (max-width:767px)' id='style320'>  .Section8 {height:280px; }  
  .WPArticleList2 {width:280px; }  
  .WPSiteDescription3 {display:none; }  
  .Box21 {margin-top:21px; margin-left:86px; }  
  .Box7 {width:320px; }  
  .Box27 {display:inherit; }  
  .Boxcopy3 {line-height:3.00; margin-top:0px; left:45px; text-align:center; }  
  .Box17 {height:50px; }  
  .Box8 {top:80px; width:300px; font-size:18px; }  
  .WPArticleTitle2 {width:100.00%; line-height:1.50; }  
  .Box28 {display:inherit; }  
  .Box22 {margin-top:-12px; left:45px; text-align:center; }  
  .WPSidebar1 {display:none; margin-right:-0px; }  
  .WPMenu1 {display:none; }  
  .Section4 {height:180px; }  
  .Box9 {top:140px; width:260px; font-size:11px; }  
  .Box23 {width:280px; left:10px; text-align:center; }  
  .Box10 {width:320px; }  
  .WPMenucopy1 {font-family:'Roboto', sans-serif; color:rgb(0,0,0); width:100.00%; }  
  .Box13 {width:100.00%; }  
  .Box19 {width:280px; margin-top:30px; }  
  .Box1 {margin-left:0px; width:100.00%; text-align:center; }  
  .Box15 {margin-top:40px; width:320px; }  
  .WPSiteTitle3 {margin-left:54px; }  
  .Box20 {width:300px; margin-left:10px; }  
</style>

    </head>
    <body>
<div id="home" class='IUPage IUSheet IUBox  home' >
  <div id="Header" class='IUHeader IUBox  Header'>
    <div id="Box12" class='IUBox  Box12' horizontalCenter='1'>
      <div id="Box13" class='IUBox  Box13' horizontalCenter='1'>
       <div id="WPSiteTitle3" class='WPSiteTitle IUBox  WPSiteTitle3' ><h1><a href="<?php echo home_url(); ?>"><?bloginfo()?></a></h1></div>
       <div id="WPSiteDescription3" class='WPSiteDescription IUBox  WPSiteDescription3' ><?bloginfo('description')?></div>
       <div id="WPMenu1" class='WPMenu IUBox  WPMenu1' ><? wp_nav_menu() ?></div>
        <div id="Box27" class='IUBox  Box27'></div>
        <div id="Box28" class='IUBox  Box28'>
         <div id="WPMenucopy1" class='WPMenu IUBox  WPMenucopy1' ><? wp_nav_menu() ?></div>
        </div>
      </div>
    </div>
  </div>
  <div id="pageContent" class='IUPageContent IUBox  pageContent'>
    <div id="Section8" class='IUSection IUBox  Section8'>
      <div id="Box7" class='IUBox  Box7' horizontalCenter='1'>
        <div id="Box8" class='IUBox  Box8' horizontalCenter='1'>
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>  
        </div>
        <div id="Box9" class='IUBox  Box9' horizontalCenter='1'>
          <p>Curabitur varius, justo vel lobortis porta, purus nibh tincidunt dui, nec egestas nisl felis ut ex.<br>Donec ut feugiat felis. Donec aliquet vulputate rutrum.</p>  
        </div>
      </div>
    </div>
    <div id="Section3" class='IUSection IUBox  Section3'>
      <div id="Box15" class='IUBox  Box15' horizontalCenter='1'>
        <div id="Box20" class='IUBox  Box20'>
          <div id="Box21" class='IUBox  Box21'></div>
          <div id="Boxcopy3" class='IUBox  Boxcopy3'>
            <p>Stanley Adams</p>  
          </div>
          <div id="Box22" class='IUBox  Box22'>
            <p>stanley.adams64@example.com<br>6387 Timber Wolf Trail<br>(301)-774-9490</p>  
          </div>
          <div id="Box23" class='IUBox  Box23'>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque vel feugiat lorem, a semper libero. Nunc facilisis lacus et felis scelerisque sollicitudin. Nulla accumsan condimentum sapien, sit amet lacinia tortor. Proin id mattis metus, et aliquet nisl. Fusce cursus velit vitae mauris aliquam lacinia.</p>  
          </div>
        </div>
        <div id="Box19" class='IUBox  Box19'>
          <div id="Box18" class='IUBox  Box18'>
            <p>Recent Post</p>  
          </div>
         <div id="WPArticleList2" class='WPArticleList IUBox  WPArticleList2' ><? while ( have_posts() ) : the_post(); ?>  <div id="WPArticle2" class='WPArticle IUBox  WPArticle2'>
             <div id="Box16" class='IUBox  Box16'></div>
            <div id="WPArticleTitle2" class='WPArticleTitle IUBox  WPArticleTitle2' ><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></div>
            <div id="WPArticleDate2" class='WPArticleDate IUBox  WPArticleDate2' ><?php echo get_the_date(); ?></div>
             <div id="Boxcopy1" class='IUBox  Boxcopy1'></div>
           </div>
         <? endwhile ?></div>
        </div>
      </div>
      <div id="Box17" class='IUBox  Box17' horizontalCenter='1'></div>
    </div>
    <div id="Section4" class='IUSection IUBox  Section4'>
      <div id="Box10" class='IUBox  Box10' horizontalCenter='1'>
        <div id="Box1" class='IUBox  Box1'>
          <p>Copyright (C) Blog Owner all rights reserved<br>Wordpress Theme powered by IUEditor</p>  
        </div>
       <div id="WPSidebar1" class='WPSidebar IUBox  WPSidebar1' ><?php dynamic_sidebar( 'IUWidgets' ); ?>  <div id="WPWidget1" class='WPWidget IUBox  WPWidget1'>
           <div id="WPWidgetTitle1" class='WPWidgetTitle IUBox  WPWidgetTitle1'></div>
           <div id="WPWidgetBody1" class='WPWidgetBody IUBox  WPWidgetBody1'></div>
         </div>
       </div>
        <div id="Box11" class='IUBox  Box11'></div>
      </div>
    </div>
  </div>
</div>

    </body>
</HTML>


